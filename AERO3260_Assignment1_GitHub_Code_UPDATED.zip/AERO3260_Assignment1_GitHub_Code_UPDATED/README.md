# AERO3260 Assignment 1 – MATLAB Computational Supplement (Updated)

This repository contains the updated MATLAB implementations used to support the calculations reported in AERO3260 Aerodynamics 1 Assignment 1.

**Student ID:** 550361509  
**N7 = 5, N8 = 0, N9 = 9**

## Contents

- `matlab/Task1_Rankine_Body.m` — Rankine body streamfunction, stagnation points and the 50 m × 10 m submarine Rankine-body calculation. This version uses `atan2` and the corrected Task 1(c) simultaneous solution.
- `matlab/Task2_Joukowsky_Transformation.m` — Joukowsky transformation, spinning-cylinder stagnation points, Kutta circulation and pressure coefficient. Surface identification is based on the correct cylinder-plane LE/TE arcs.
- `matlab/Task3_Thin_Aerofoil_LVM.m` — camber line, Fourier coefficients obtained by numerical integration, zero-lift angle, thin-airfoil lift/moment and 10-panel vortex LVM comparison.
- `matlab/Task4a_4b_Cylinder_SourcePanel.m` — 64-panel constant-source cylinder method, numerical streamlines and analytical/numerical Cp comparison for Tasks 4(a) and 4(b).
- `matlab/Task4c_NACA0021_Source_Panel.m` — 64-panel NACA 0021 source-panel method at α = 0°, with XFOIL comparison.
- `matlab/Task4d_NACA0021_Source_Vortex.m` — 64-panel NACA 0021 source–vortex panel method at α = 10°, including Kutta condition, Cp, forces and streamlines.
- `matlab/Task4e_NACA0021_VortexPanel_XFOIL.m` — validated Task 4(e) source–vortex implementation with robust XFOIL-file discovery, Cp comparison, force coefficients and error metrics.

## XFOIL data

The `xfoil/` folder contains the XFOIL pressure-coefficient files used for the report comparisons:

- `xfoil_NACA0021_alpha0_inviscid.txt` — NACA 0021, α = 0°
- `xfoil_cp10.txt` — NACA 0021, α = 10°

The comparisons are based on inviscid XFOIL data.

## Important corrected result – Task 1(c)

For the 50 m stagnation-to-stagnation length, 10 m maximum thickness and `Uinf = 5 m/s`, the corrected simultaneous solution is approximately:

- `x0 = 23.22771583 m`
- `sigma = 57.80207426 m^2/s`
- stagnation locations: `x = ±25 m`
- source/sink spacing: `2*x0 = 46.45543166 m`

The MATLAB script solves the two governing equations numerically and prints independent residual checks.

## Reproducibility

1. Open MATLAB.
2. Add the `matlab` folder to the MATLAB path or make it the Current Folder.
3. Run the desired script.
4. For Task 4(c), keep `xfoil_NACA0021_alpha0_inviscid.txt` available in the MATLAB Current Folder/script folder.
5. For Task 4(e), the script first searches its own folder and the Current Folder. If the XFOIL file is not found, it opens a file-selection dialog.

No external MATLAB toolbox is intentionally required beyond standard MATLAB functionality used by the scripts; Task 1(c) uses `fsolve` if the Optimization Toolbox is available.

## Assignment scope

Task 4(g) is not included because it is specified for AERO8260/9260 rather than AERO3260.

## Academic use

This repository is supplementary computational material associated with an AERO3260 Aerodynamics 1 assignment. The submitted assessment report remains the primary assessed document.
